import { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CartProvider } from '@/context/CartContext';
import Header from '@/sections/Header';
import Hero from '@/sections/Hero';
import About from '@/sections/About';
import Collection from '@/sections/Collection';
import ProductGrid from '@/sections/ProductGrid';
import Categories from '@/sections/Categories';
import Testimonials from '@/sections/Testimonials';
import Features from '@/sections/Features';
import Instagram from '@/sections/Instagram';
import Footer from '@/sections/Footer';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

function App() {
  useEffect(() => {
    // Configure ScrollTrigger defaults
    ScrollTrigger.defaults({
      toggleActions: 'play none none reverse',
    });

    // Refresh ScrollTrigger on window resize
    const handleResize = () => {
      ScrollTrigger.refresh();
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, []);

  return (
    <CartProvider>
      <div className="relative min-h-screen bg-black text-white overflow-x-hidden">
        {/* Noise overlay */}
        <div className="noise-overlay" />
        
        {/* Header */}
        <Header />
        
        {/* Main Content */}
        <main>
          <Hero />
          <About />
          <Collection />
          <ProductGrid />
          <Categories />
          <Testimonials />
          <Features />
          <Instagram />
        </main>
        
        {/* Footer */}
        <Footer />
      </div>
    </CartProvider>
  );
}

export default App;
