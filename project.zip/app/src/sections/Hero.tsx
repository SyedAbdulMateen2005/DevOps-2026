import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const titleLines = titleRef.current?.querySelectorAll('.title-line');
      if (titleLines) {
        gsap.fromTo(
          titleLines,
          { y: 80, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.15,
            ease: 'expo.out',
            delay: 0.2,
          }
        );
      }

      gsap.fromTo(
        descRef.current,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'expo.out',
          delay: 0.8,
        }
      );

      gsap.fromTo(
        ctaRef.current,
        { scale: 0.9, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.5,
          ease: 'elastic.out(1, 0.5)',
          delay: 1,
        }
      );

      gsap.fromTo(
        imageRef.current,
        { x: 80, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          ease: 'expo.out',
          delay: 0.3,
        }
      );

      gsap.to(titleRef.current, {
        y: -50,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });

      gsap.to(imageRef.current, {
        y: -30,
        scale: 1.05,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToCollection = () => {
    const element = document.querySelector('#collection');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="home"
      className="relative min-h-screen w-full bg-black overflow-hidden"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-black to-lumiere-gray/20" />
      
      {/* Grid pattern */}
      <div 
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `linear-gradient(rgba(242, 254, 111, 0.3) 1px, transparent 1px),
                            linear-gradient(90deg, rgba(242, 254, 111, 0.3) 1px, transparent 1px)`,
          backgroundSize: '50px 50px',
        }}
      />

      <div className="relative z-10 min-h-screen w-full grid lg:grid-cols-2 items-center">
        {/* Content */}
        <div className="px-6 lg:px-12 xl:px-20 py-32 lg:py-0 order-2 lg:order-1">
          <div ref={titleRef} className="space-y-1">
            <div className="overflow-hidden">
              <h1 className="title-line font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight">
                Fashion
              </h1>
            </div>
            <div className="overflow-hidden">
              <h1 className="title-line font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight">
                Beyond
              </h1>
            </div>
            <div className="overflow-hidden">
              <h1 className="title-line font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-lumiere-yellow leading-tight">
                Boundaries
              </h1>
            </div>
          </div>

          <p
            ref={descRef}
            className="mt-6 lg:mt-8 text-base lg:text-lg text-white/70 max-w-md leading-relaxed opacity-0"
          >
            Discover our latest collection designed for the bold and the brave. 
            Elevate your style with pieces that make a statement.
          </p>

          <button
            ref={ctaRef}
            onClick={scrollToCollection}
            className="mt-8 lg:mt-10 group inline-flex items-center gap-3 px-8 py-4 bg-lumiere-yellow text-black font-semibold rounded-full hover:bg-white transition-all duration-300 glow-primary opacity-0"
          >
            Explore Collection
            <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform duration-300" />
          </button>
        </div>

        {/* Image */}
        <div
          ref={imageRef}
          className="relative h-[50vh] lg:h-screen order-1 lg:order-2 opacity-0"
        >
          <div className="absolute inset-0 lg:clip-diagonal-reverse">
            <img
              src="/hero-model.jpg"
              alt="Fashion Model"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-transparent lg:opacity-100 opacity-70" />
          </div>
          
          {/* Decorative elements */}
          <div className="absolute bottom-20 left-0 w-24 h-24 border border-lumiere-yellow/30 rounded-full hidden lg:block" />
          <div className="absolute top-40 left-10 w-3 h-3 bg-lumiere-yellow rounded-full hidden lg:block animate-pulse" />
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black to-transparent" />
    </section>
  );
}
