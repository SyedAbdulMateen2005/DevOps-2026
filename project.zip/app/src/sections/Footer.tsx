import { useEffect, useRef, useState } from 'react';
import { Send, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const quickLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Shop', href: '#shop' },
  { label: 'Contact', href: '#contact' },
];

const supportLinks = [
  { label: 'FAQ', href: '#' },
  { label: 'Shipping', href: '#' },
  { label: 'Returns', href: '#' },
  { label: 'Size Guide', href: '#' },
];

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Youtube, href: '#', label: 'Youtube' },
];

export default function Footer() {
  const footerRef = useRef<HTMLElement>(null);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.footer-border',
        { scaleX: 0 },
        {
          scaleX: 1,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        '.footer-column',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      setEmail('');
      setTimeout(() => setIsSubmitted(false), 3000);
    }
  };

  const scrollToSection = (href: string) => {
    if (href.startsWith('#')) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <footer ref={footerRef} className="relative w-full bg-black pt-16 lg:pt-20 pb-8">
      {/* Top border */}
      <div className="footer-border absolute top-0 left-1/2 -translate-x-1/2 w-[90%] h-px bg-gradient-to-r from-transparent via-white/20 to-transparent origin-center" />

      <div className="w-full px-6 lg:px-12 xl:px-20">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8 mb-12 lg:mb-16">
          {/* Brand Column */}
          <div className="footer-column lg:col-span-1">
            <a href="#home" className="inline-block font-display text-2xl lg:text-3xl font-bold text-white mb-4">
              LUMIÈRE
            </a>
            <p className="text-white/60 mb-6 leading-relaxed text-sm lg:text-base">
              Fashion beyond boundaries. Discover your unique style with our curated collection of premium apparel.
            </p>
            
            {/* Newsletter */}
            <form onSubmit={handleSubmit} className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/40 focus:outline-none focus:border-lumiere-yellow transition-colors duration-300 text-sm"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-lumiere-yellow text-black rounded-md hover:bg-white transition-colors duration-300"
                aria-label="Subscribe"
              >
                {isSubmitted ? (
                  <span className="text-sm font-semibold">✓</span>
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </button>
            </form>
            {isSubmitted && (
              <p className="text-lumiere-yellow text-sm mt-2 animate-fade-in">
                Thank you for subscribing!
              </p>
            )}
          </div>

          {/* Quick Links */}
          <div className="footer-column">
            <h4 className="font-display text-lg font-semibold text-white mb-5">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className="text-white/60 hover:text-lumiere-yellow transition-colors duration-200 text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div className="footer-column">
            <h4 className="font-display text-lg font-semibold text-white mb-5">
              Support
            </h4>
            <ul className="space-y-3">
              {supportLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-white/60 hover:text-lumiere-yellow transition-colors duration-200 text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div className="footer-column">
            <h4 className="font-display text-lg font-semibold text-white mb-5">
              Connect
            </h4>
            <div className="flex gap-3 mb-6">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    className="p-3 bg-white/5 rounded-full text-white/60 hover:bg-lumiere-yellow hover:text-black transition-all duration-300"
                    aria-label={social.label}
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
            <div className="text-white/60 text-sm">
              <p>hello@lumiere.com</p>
              <p className="mt-1">+1 (555) 123-4567</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="footer-column pt-6 border-t border-white/10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
            <p className="text-white/40 text-sm text-center lg:text-left">
              © 2024 LUMIÈRE Fashion. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-white/40 hover:text-lumiere-yellow transition-colors">Privacy Policy</a>
              <a href="#" className="text-white/40 hover:text-lumiere-yellow transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
