import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const categories = [
  {
    title: 'Women',
    image: '/category-women.jpg',
    link: '#shop',
    description: 'Elegant & Bold',
  },
  {
    title: 'Men',
    image: '/category-men.jpg',
    link: '#shop',
    description: 'Sophisticated & Strong',
  },
];

export default function Categories() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.category-card',
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.15,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full bg-black py-20 lg:py-32"
    >
      <div className="w-full px-6 lg:px-12 xl:px-20">
        {/* Section Header */}
        <div className="text-center mb-12 lg:mb-16">
          <span className="inline-block text-sm font-medium text-lumiere-yellow tracking-widest uppercase mb-4">
            Browse by Category
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-white">
            Find Your Style
          </h2>
        </div>

        {/* Categories Grid - Equal height cards */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {categories.map((category) => (
            <a
              key={category.title}
              href={category.link}
              className="category-card group relative block overflow-hidden rounded-2xl aspect-[4/5] md:aspect-[3/4]"
            >
              {/* Background Image */}
              <img
                src={category.image}
                alt={category.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
              
              {/* Content */}
              <div className="absolute inset-0 flex flex-col justify-end p-8 lg:p-12">
                <span className="text-white/60 text-sm uppercase tracking-wider mb-2 transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  {category.description}
                </span>
                <h3 className="font-display text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-6 group-hover:tracking-wider transition-all duration-300">
                  {category.title}
                </h3>
                <div className="inline-flex items-center gap-3 px-6 py-3 bg-lumiere-yellow text-black font-semibold rounded-full w-fit transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 hover:bg-white">
                  Explore
                  <ArrowRight className="w-5 h-5" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
