import { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import Checkout from './Checkout';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Collection', href: '#collection' },
  { label: 'Shop', href: '#shop' },
  { label: 'Contact', href: '#contact' },
];

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const { items, totalItems, totalPrice, removeFromCart, updateQuantity, isCartOpen, setIsCartOpen } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setTimeout(() => {
      setIsCheckoutOpen(true);
    }, 300);
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'glass py-3'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="w-full px-6 lg:px-12">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#home');
              }}
              className="font-display text-2xl lg:text-3xl font-bold text-white tracking-wider hover:text-lumiere-yellow transition-colors duration-300"
            >
              LUMIÈRE
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection(link.href);
                  }}
                  className="relative text-sm font-medium text-white/80 hover:text-white transition-colors duration-200 animated-underline"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            {/* Right Section */}
            <div className="flex items-center gap-3">
              {/* Cart */}
              <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
                <SheetTrigger asChild>
                  <button
                    className="relative p-2 text-white hover:text-lumiere-yellow transition-colors duration-200"
                    aria-label="Open cart"
                  >
                    <ShoppingBag className="w-5 h-5" />
                    {totalItems > 0 && (
                      <span className="absolute -top-1 -right-1 w-5 h-5 bg-lumiere-yellow text-black text-xs font-bold rounded-full flex items-center justify-center animate-scale-in">
                        {totalItems}
                      </span>
                    )}
                  </button>
                </SheetTrigger>
                <SheetContent className="w-full sm:max-w-md bg-lumiere-dark border-lumiere-gray">
                  <SheetHeader>
                    <SheetTitle className="font-display text-xl text-white">Your Cart ({totalItems})</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 flex flex-col h-[calc(100vh-180px)]">
                    {items.length === 0 ? (
                      <div className="flex-1 flex flex-col items-center justify-center text-white/60">
                        <ShoppingBag className="w-16 h-16 mb-4" />
                        <p className="text-lg">Your cart is empty</p>
                        <p className="text-sm mt-2">Add some items to get started</p>
                      </div>
                    ) : (
                      <>
                        <div className="flex-1 overflow-auto space-y-4 pr-2">
                          {items.map((item) => (
                            <div
                              key={item.id}
                              className="flex gap-4 p-3 bg-lumiere-gray rounded-lg"
                            >
                              <img
                                src={item.image}
                                alt={item.name}
                                className="w-20 h-24 object-cover rounded"
                              />
                              <div className="flex-1 min-w-0">
                                <h4 className="text-white font-medium text-sm truncate">{item.name}</h4>
                                <p className="text-lumiere-yellow text-sm mt-1">
                                  ${item.price.toFixed(2)}
                                </p>
                                <div className="flex items-center gap-2 mt-2">
                                  <button
                                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                    className="p-1 text-white/60 hover:text-white transition-colors"
                                  >
                                    <Minus className="w-4 h-4" />
                                  </button>
                                  <span className="text-white text-sm w-6 text-center">
                                    {item.quantity}
                                  </span>
                                  <button
                                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                    className="p-1 text-white/60 hover:text-white transition-colors"
                                  >
                                    <Plus className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => removeFromCart(item.id)}
                                    className="p-1 text-white/60 hover:text-red-400 transition-colors ml-auto"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="border-t border-lumiere-gray pt-4 mt-4">
                          <div className="flex justify-between text-white mb-4">
                            <span className="text-lg font-medium">Total</span>
                            <span className="text-xl font-bold text-lumiere-yellow">
                              ${totalPrice.toFixed(2)}
                            </span>
                          </div>
                          <button 
                            onClick={handleCheckout}
                            className="w-full py-4 bg-lumiere-yellow text-black font-semibold rounded-lg hover:bg-white transition-colors duration-300"
                          >
                            Checkout
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </SheetContent>
              </Sheet>

              {/* Mobile Menu Button */}
              <button
                className="lg:hidden p-2 text-white"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <nav className="lg:hidden mt-4 pb-4 border-t border-white/10 pt-4 animate-slide-down">
              <div className="flex flex-col gap-4">
                {navLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className="text-lg font-medium text-white/80 hover:text-lumiere-yellow transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Checkout Modal */}
      <Checkout isOpen={isCheckoutOpen} onClose={() => setIsCheckoutOpen(false)} />
    </>
  );
}
