import { useState } from 'react';
import { CreditCard, Truck, Check, ChevronRight, ChevronLeft, ShoppingBag } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface CheckoutProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Checkout({ isOpen, onClose }: CheckoutProps) {
  const { items, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmation'>('shipping');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [shippingInfo, setShippingInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zipCode: '',
    country: 'US',
  });

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setIsComplete(true);
      clearCart();
    }, 2000);
  };

  const handleClose = () => {
    onClose();
    // Reset state after animation
    setTimeout(() => {
      setStep('shipping');
      setIsComplete(false);
      setShippingInfo({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        zipCode: '',
        country: 'US',
      });
    }, 300);
  };

  const subtotal = totalPrice;
  const shipping = subtotal > 100 ? 0 : 15;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  if (isComplete) {
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="bg-lumiere-dark border-lumiere-gray max-w-md">
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-20 h-20 bg-lumiere-yellow rounded-full flex items-center justify-center mb-6 animate-scale-in">
              <Check className="w-10 h-10 text-black" />
            </div>
            <h2 className="font-display text-2xl font-bold text-white mb-3">
              Order Confirmed!
            </h2>
            <p className="text-white/60 mb-8">
              Thank you for your purchase. You will receive a confirmation email shortly.
            </p>
            <button
              onClick={handleClose}
              className="px-8 py-3 bg-lumiere-yellow text-black font-semibold rounded-full hover:bg-white transition-colors duration-300"
            >
              Continue Shopping
            </button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-lumiere-dark border-lumiere-gray max-w-4xl max-h-[90vh] overflow-hidden p-0">
        <div className="grid lg:grid-cols-[1fr_350px] h-full">
          {/* Main Content */}
          <div className="p-6 lg:p-8 overflow-y-auto max-h-[90vh]">
            <DialogHeader className="mb-6">
              <div className="flex items-center gap-2 text-sm text-white/60 mb-2">
                <button onClick={handleClose} className="hover:text-lumiere-yellow transition-colors">
                  <ShoppingBag className="w-4 h-4" />
                </button>
                <ChevronRight className="w-4 h-4" />
                <span>Checkout</span>
                <ChevronRight className="w-4 h-4" />
                <span className="text-lumiere-yellow capitalize">{step}</span>
              </div>
              <DialogTitle className="font-display text-2xl text-white">
                {step === 'shipping' && 'Shipping Information'}
                {step === 'payment' && 'Payment Method'}
              </DialogTitle>
            </DialogHeader>

            {/* Progress Bar */}
            <div className="flex gap-2 mb-8">
              <div className={`flex-1 h-1 rounded-full ${step === 'shipping' ? 'bg-lumiere-yellow' : 'bg-lumiere-yellow/50'}`} />
              <div className={`flex-1 h-1 rounded-full ${step === 'payment' ? 'bg-lumiere-yellow' : 'bg-white/20'}`} />
              <div className="flex-1 h-1 rounded-full bg-white/20" />
            </div>

            {step === 'shipping' && (
              <form onSubmit={handleShippingSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-white/60 mb-2">First Name</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.firstName}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, firstName: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-white/60 mb-2">Last Name</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.lastName}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, lastName: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-white/60 mb-2">Email</label>
                  <input
                    type="email"
                    required
                    value={shippingInfo.email}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm text-white/60 mb-2">Phone</label>
                  <input
                    type="tel"
                    required
                    value={shippingInfo.phone}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>

                <div>
                  <label className="block text-sm text-white/60 mb-2">Address</label>
                  <input
                    type="text"
                    required
                    value={shippingInfo.address}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                    placeholder="123 Fashion Street"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-white/60 mb-2">City</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.city}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                      placeholder="New York"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-white/60 mb-2">ZIP Code</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.zipCode}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, zipCode: e.target.value })}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                      placeholder="10001"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-lumiere-yellow text-black font-semibold rounded-lg hover:bg-white transition-colors duration-300 flex items-center justify-center gap-2 mt-6"
                >
                  Continue to Payment
                  <ChevronRight className="w-5 h-5" />
                </button>
              </form>
            )}

            {step === 'payment' && (
              <form onSubmit={handlePaymentSubmit} className="space-y-4">
                {/* Payment Methods */}
                <div className="space-y-3 mb-6">
                  <label className="flex items-center gap-4 p-4 bg-white/5 border border-lumiere-yellow rounded-lg cursor-pointer">
                    <input type="radio" name="payment" defaultChecked className="w-4 h-4 accent-lumiere-yellow" />
                    <CreditCard className="w-5 h-5 text-lumiere-yellow" />
                    <span className="text-white">Credit Card</span>
                  </label>
                  <label className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-lg cursor-pointer hover:border-white/30 transition-colors">
                    <input type="radio" name="payment" className="w-4 h-4 accent-lumiere-yellow" />
                    <span className="text-white">PayPal</span>
                  </label>
                  <label className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-lg cursor-pointer hover:border-white/30 transition-colors">
                    <input type="radio" name="payment" className="w-4 h-4 accent-lumiere-yellow" />
                    <span className="text-white">Apple Pay</span>
                  </label>
                </div>

                <div>
                  <label className="block text-sm text-white/60 mb-2">Card Number</label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                    placeholder="1234 5678 9012 3456"
                  />
                </div>

                <div>
                  <label className="block text-sm text-white/60 mb-2">Cardholder Name</label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                    placeholder="John Doe"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-white/60 mb-2">Expiry Date</label>
                    <input
                      type="text"
                      required
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                      placeholder="MM/YY"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-white/60 mb-2">CVV</label>
                    <input
                      type="text"
                      required
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-white/30 focus:outline-none focus:border-lumiere-yellow transition-colors"
                      placeholder="123"
                    />
                  </div>
                </div>

                <div className="flex gap-4 mt-6">
                  <button
                    type="button"
                    onClick={() => setStep('shipping')}
                    className="flex-1 py-4 border border-white/20 text-white font-semibold rounded-lg hover:bg-white/5 transition-colors duration-300 flex items-center justify-center gap-2"
                  >
                    <ChevronLeft className="w-5 h-5" />
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="flex-1 py-4 bg-lumiere-yellow text-black font-semibold rounded-lg hover:bg-white transition-colors duration-300 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        Pay ${total.toFixed(2)}
                        <ChevronRight className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="hidden lg:block bg-lumiere-gray/30 p-6 lg:p-8 border-l border-white/10">
            <h3 className="font-display text-lg font-semibold text-white mb-6">Order Summary</h3>
            
            {/* Items */}
            <div className="space-y-4 mb-6 max-h-60 overflow-y-auto">
              {items.map((item) => (
                <div key={item.id} className="flex gap-3">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-20 object-cover rounded"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm truncate">{item.name}</p>
                    <p className="text-white/60 text-xs">Qty: {item.quantity}</p>
                    <p className="text-lumiere-yellow text-sm">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="space-y-3 pt-6 border-t border-white/10">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Subtotal</span>
                <span className="text-white">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Shipping</span>
                <span className="text-white">{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Tax (8%)</span>
                <span className="text-white">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-3 border-t border-white/10">
                <span className="text-white font-semibold">Total</span>
                <span className="text-lumiere-yellow font-bold text-xl">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Shipping Badge */}
            {subtotal > 100 && (
              <div className="mt-6 p-3 bg-lumiere-yellow/10 border border-lumiere-yellow/30 rounded-lg flex items-center gap-3">
                <Truck className="w-5 h-5 text-lumiere-yellow" />
                <span className="text-lumiere-yellow text-sm">Free shipping applied!</span>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
