import { useEffect, useRef, useState } from 'react';
import { Quote, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import type { Testimonial } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Sarah Mitchell',
    role: 'Fashion Editor',
    quote: 'LUMIÈRE has completely transformed my wardrobe. The quality is exceptional, and every piece makes me feel confident and stylish. Their attention to detail is unmatched.',
    image: '/testimonial-1.jpg',
  },
  {
    id: 2,
    name: 'James Anderson',
    role: 'Creative Director',
    quote: 'As someone who works in the creative industry, I need clothing that stands out. LUMIÈRE delivers bold designs without compromising on comfort or quality.',
    image: '/testimonial-2.jpg',
  },
  {
    id: 3,
    name: 'Emma Richardson',
    role: 'Entrepreneur',
    quote: 'The customer service is as impressive as the clothing. From personalized styling advice to seamless delivery, LUMIÈRE makes luxury fashion accessible.',
    image: '/testimonial-3.jpg',
  },
];

export default function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.testimonials-title',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        '.testimonial-container',
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const goTo = (index: number) => {
    setActiveIndex(index);
  };

  const goPrev = () => {
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goNext = () => {
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
  };

  const currentTestimonial = testimonials[activeIndex];

  return (
    <section
      ref={sectionRef}
      className="relative w-full bg-black py-20 lg:py-32 overflow-hidden"
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-lumiere-gray/10 to-transparent" />

      <div className="relative w-full px-6 lg:px-12 xl:px-20">
        {/* Header */}
        <div className="testimonials-title text-center mb-12 lg:mb-16">
          <span className="inline-block text-sm font-medium text-lumiere-yellow tracking-widest uppercase mb-4">
            Testimonials
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-white">
            What They Say
          </h2>
        </div>

        {/* Testimonials - Clean Single Card Layout */}
        <div className="testimonial-container max-w-3xl mx-auto">
          <div className="relative bg-lumiere-gray/30 backdrop-blur-sm rounded-3xl p-8 lg:p-12 border border-white/10">
            {/* Quote icon */}
            <Quote className="w-12 h-12 text-lumiere-yellow/40 mb-6" />

            {/* Stars */}
            <div className="flex gap-1 mb-6">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-lumiere-yellow text-lumiere-yellow" />
              ))}
            </div>

            {/* Quote text with transition */}
            <div className="min-h-[120px] lg:min-h-[100px]">
              <p 
                key={currentTestimonial.id}
                className="text-lg lg:text-xl text-white/90 leading-relaxed animate-fade-in"
              >
                "{currentTestimonial.quote}"
              </p>
            </div>

            {/* Author */}
            <div className="flex items-center gap-4 mt-8 pt-8 border-t border-white/10">
              <img
                src={currentTestimonial.image}
                alt={currentTestimonial.name}
                className="w-14 h-14 rounded-full object-cover border-2 border-lumiere-yellow"
              />
              <div>
                <h4 className="font-display text-lg font-semibold text-white">
                  {currentTestimonial.name}
                </h4>
                <p className="text-white/60 text-sm">{currentTestimonial.role}</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-6 mt-8">
            <button
              onClick={goPrev}
              className="p-3 border border-white/20 rounded-full text-white hover:bg-lumiere-yellow hover:text-black hover:border-lumiere-yellow transition-all duration-300"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Dots */}
            <div className="flex gap-3">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goTo(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === activeIndex
                      ? 'bg-lumiere-yellow w-8'
                      : 'bg-white/30 hover:bg-white/50'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <button
              onClick={goNext}
              className="p-3 border border-white/20 rounded-full text-white hover:bg-lumiere-yellow hover:text-black hover:border-lumiere-yellow transition-all duration-300"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
