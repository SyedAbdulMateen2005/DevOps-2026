import { useEffect, useRef } from 'react';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useCart } from '@/context/CartContext';
import type { Product } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const newArrivals: Product[] = [
  { id: 1, name: 'Midnight Elegance Dress', price: 289, image: '/product-1.jpg', category: 'Dresses' },
  { id: 2, name: 'Rebel Leather Jacket', price: 349, image: '/product-2.jpg', category: 'Outerwear' },
  { id: 3, name: 'Luxe Signature Bag', price: 425, image: '/product-3.jpg', category: 'Accessories' },
  { id: 4, name: 'Silk Dream Blouse', price: 178, image: '/product-4.jpg', category: 'Tops' },
  { id: 5, name: 'Golden Hour Necklace', price: 195, image: '/product-5.jpg', category: 'Jewelry' },
];

export default function Collection() {
  const sectionRef = useRef<HTMLElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const { addToCart, setIsCartOpen } = useCart();

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.collection-title',
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        '.collection-card',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 320;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    setIsCartOpen(true);
  };

  return (
    <section
      ref={sectionRef}
      id="collection"
      className="relative w-full bg-black py-20 lg:py-32"
    >
      <div className="w-full px-6 lg:px-12 xl:px-20">
        {/* Header */}
        <div className="collection-title flex flex-col lg:flex-row lg:items-end justify-between mb-10 lg:mb-12">
          <div>
            <span className="inline-block text-sm font-medium text-lumiere-yellow tracking-widest uppercase mb-4">
              New Arrivals
            </span>
            <h2 className="font-display text-4xl lg:text-5xl font-bold text-white">
              This Week's Highlights
            </h2>
          </div>
          
          {/* Navigation Arrows */}
          <div className="flex gap-3 mt-6 lg:mt-0">
            <button
              onClick={() => scroll('left')}
              className="p-3 lg:p-4 border border-white/20 rounded-full text-white hover:bg-lumiere-yellow hover:text-black hover:border-lumiere-yellow transition-all duration-300"
              aria-label="Scroll left"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="p-3 lg:p-4 border border-white/20 rounded-full text-white hover:bg-lumiere-yellow hover:text-black hover:border-lumiere-yellow transition-all duration-300"
              aria-label="Scroll right"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Horizontal Scroll Container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-4 lg:gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {newArrivals.map((product) => (
            <div
              key={product.id}
              className="collection-card flex-shrink-0 w-[260px] lg:w-[300px] snap-start group"
            >
              {/* Image - Fixed aspect ratio */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-lumiere-gray mb-4">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center">
                  <button
                    onClick={() => handleAddToCart(product)}
                    className="px-6 py-3 bg-lumiere-yellow text-black font-semibold rounded-full transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 hover:bg-white"
                  >
                    Add to Cart
                  </button>
                </div>
                
                {/* Category tag */}
                <span className="absolute top-3 left-3 px-3 py-1 bg-black/70 text-white text-xs font-medium rounded-full">
                  {product.category}
                </span>
              </div>
              
              {/* Product Info */}
              <div className="space-y-1">
                <h3 className="font-display text-base lg:text-lg font-medium text-white group-hover:text-lumiere-yellow transition-colors duration-300 truncate">
                  {product.name}
                </h3>
                <p className="text-lumiere-yellow font-semibold">
                  ${product.price.toFixed(2)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
