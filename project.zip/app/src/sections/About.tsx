import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        imageRef.current,
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      const contentElements = contentRef.current?.querySelectorAll('.animate-item');
      if (contentElements) {
        gsap.fromTo(
          contentElements,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 50%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative min-h-screen w-full bg-black py-20 lg:py-32"
    >
      <div className="w-full px-6 lg:px-12 xl:px-20">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          {/* Image */}
          <div
            ref={imageRef}
            className="relative aspect-[3/4] overflow-hidden rounded-2xl"
          >
            <img
              src="/about-model.jpg"
              alt="About LUMIÈRE"
              className="w-full h-full object-cover"
            />
            {/* Decorative frame */}
            <div className="absolute -bottom-4 -right-4 w-full h-full border-2 border-lumiere-yellow/30 rounded-2xl -z-10" />
          </div>

          {/* Content */}
          <div ref={contentRef} className="lg:pl-8">
            <span className="animate-item inline-block text-sm font-medium text-lumiere-yellow tracking-widest uppercase mb-4">
              About Us
            </span>
            
            <h2 className="animate-item font-display text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
              Crafting Style<br />
              <span className="text-lumiere-yellow">Since 2010</span>
            </h2>
            
            <p className="animate-item text-base lg:text-lg text-white/70 leading-relaxed mb-4">
              We believe fashion is more than clothing—it's a statement of who you are. 
              Our designs blend timeless elegance with contemporary edge, creating pieces 
              that empower you to express your unique identity.
            </p>
            
            <p className="animate-item text-base lg:text-lg text-white/70 leading-relaxed mb-8">
              Every garment in our collection is meticulously crafted with premium materials 
              and attention to detail. From sketch to final stitch, we ensure excellence 
              at every step of the journey.
            </p>

            <div className="animate-item grid grid-cols-3 gap-4 lg:gap-6 mb-10">
              <div className="text-center p-4 bg-white/5 rounded-xl">
                <div className="font-display text-2xl lg:text-3xl font-bold text-lumiere-yellow">15+</div>
                <div className="text-xs lg:text-sm text-white/60 mt-1">Years</div>
              </div>
              <div className="text-center p-4 bg-white/5 rounded-xl">
                <div className="font-display text-2xl lg:text-3xl font-bold text-lumiere-yellow">50K+</div>
                <div className="text-xs lg:text-sm text-white/60 mt-1">Customers</div>
              </div>
              <div className="text-center p-4 bg-white/5 rounded-xl">
                <div className="font-display text-2xl lg:text-3xl font-bold text-lumiere-yellow">200+</div>
                <div className="text-xs lg:text-sm text-white/60 mt-1">Products</div>
              </div>
            </div>
            
            <button className="animate-item group inline-flex items-center gap-3 px-8 py-4 border-2 border-lumiere-yellow text-lumiere-yellow font-semibold rounded-full hover:bg-lumiere-yellow hover:text-black transition-all duration-300">
              Our Story
              <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform duration-300" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
