import { useEffect, useRef } from 'react';
import { Instagram as InstagramIcon, ExternalLink } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const instagramImages = [
  { src: '/instagram-1.jpg', alt: 'Behind the scenes' },
  { src: '/instagram-2.jpg', alt: 'Accessories flat lay' },
  { src: '/instagram-3.jpg', alt: 'Runway show' },
  { src: '/instagram-4.jpg', alt: 'Street style' },
  { src: '/instagram-5.jpg', alt: 'Product detail' },
  { src: '/instagram-6.jpg', alt: 'Boutique interior' },
];

export default function Instagram() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.instagram-title',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        '.instagram-image',
        { scale: 0.9, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.5,
          stagger: 0.08,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: '.instagram-grid',
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative w-full bg-black py-20 lg:py-32"
    >
      <div className="w-full px-6 lg:px-12 xl:px-20">
        {/* Header */}
        <div className="instagram-title text-center mb-12">
          <span className="inline-block text-sm font-medium text-lumiere-yellow tracking-widest uppercase mb-4">
            Follow Us
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-white flex items-center justify-center gap-4">
            <InstagramIcon className="w-8 h-8 lg:w-10 lg:h-10 text-lumiere-yellow" />
            @lumiere_fashion
          </h2>
        </div>

        {/* Instagram Grid - Uniform 3 columns */}
        <div className="instagram-grid grid grid-cols-2 md:grid-cols-3 gap-3 lg:gap-4">
          {instagramImages.map((image, index) => (
            <a
              key={index}
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="instagram-image relative group overflow-hidden rounded-lg aspect-square"
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <InstagramIcon className="w-8 h-8 text-white" />
              </div>
            </a>
          ))}
        </div>

        {/* Follow Button */}
        <div className="text-center mt-10">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-600 via-pink-500 to-orange-400 text-white font-semibold rounded-full hover:opacity-90 transition-opacity duration-300"
          >
            Follow on Instagram
            <ExternalLink className="w-5 h-5" />
          </a>
        </div>
      </div>
    </section>
  );
}
