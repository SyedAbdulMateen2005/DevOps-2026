import { useEffect, useRef } from 'react';
import { ShoppingBag, Eye, ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useCart } from '@/context/CartContext';
import type { Product } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

const products: Product[] = [
  { id: 1, name: 'Midnight Elegance Dress', price: 289, image: '/product-1.jpg', category: 'Dresses' },
  { id: 2, name: 'Rebel Leather Jacket', price: 349, image: '/product-2.jpg', category: 'Outerwear' },
  { id: 3, name: 'Luxe Signature Bag', price: 425, image: '/product-3.jpg', category: 'Accessories' },
  { id: 4, name: 'Silk Dream Blouse', price: 178, image: '/product-4.jpg', category: 'Tops' },
  { id: 5, name: 'Golden Hour Necklace', price: 195, image: '/product-5.jpg', category: 'Jewelry' },
  { id: 6, name: 'Executive Navy Suit', price: 599, image: '/product-6.jpg', category: 'Suits' },
  { id: 7, name: 'Midnight Sunglasses', price: 245, image: '/product-7.jpg', category: 'Accessories' },
  { id: 8, name: 'Prestige Timepiece', price: 899, image: '/product-8.jpg', category: 'Watches' },
];

export default function ProductGrid() {
  const sectionRef = useRef<HTMLElement>(null);
  const { addToCart, setIsCartOpen } = useCart();

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.shop-title',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        '.product-item',
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.08,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: '.products-grid',
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    setIsCartOpen(true);
  };

  return (
    <section
      ref={sectionRef}
      id="shop"
      className="relative w-full bg-black py-20 lg:py-32"
    >
      <div className="w-full px-6 lg:px-12 xl:px-20">
        {/* Header */}
        <div className="shop-title text-center mb-12 lg:mb-16">
          <span className="inline-block text-sm font-medium text-lumiere-yellow tracking-widest uppercase mb-4">
            Our Collection
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-white">
            Shop the Look
          </h2>
        </div>

        {/* Product Grid - Uniform 4 columns */}
        <div className="products-grid grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="product-item group"
            >
              {/* Image Container - Fixed aspect ratio */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-lumiere-gray">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-end">
                  <div className="w-full p-4 flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <button
                          className="flex-1 py-3 bg-white/20 backdrop-blur-sm text-white font-medium rounded-lg hover:bg-white/30 transition-colors duration-200 flex items-center justify-center gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          Quick View
                        </button>
                      </DialogTrigger>
                      <DialogContent className="bg-lumiere-dark border-lumiere-gray max-w-2xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="font-display text-2xl text-white">{product.name}</DialogTitle>
                        </DialogHeader>
                        <div className="grid md:grid-cols-2 gap-6 mt-4">
                          <div className="aspect-[3/4] rounded-lg overflow-hidden">
                            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="flex flex-col justify-center">
                            <span className="text-lumiere-yellow text-sm font-medium uppercase tracking-wider">{product.category}</span>
                            <h3 className="font-display text-2xl lg:text-3xl font-bold text-white mt-2">{product.name}</h3>
                            <p className="text-xl lg:text-2xl text-lumiere-yellow font-semibold mt-4">${product.price.toFixed(2)}</p>
                            <p className="text-white/60 mt-4 leading-relaxed text-sm lg:text-base">
                              Experience luxury with this exquisite piece from our collection. 
                              Crafted with premium materials and attention to every detail.
                            </p>
                            <button
                              onClick={() => handleAddToCart(product)}
                              className="mt-6 py-4 bg-lumiere-yellow text-black font-semibold rounded-lg hover:bg-white transition-colors duration-300 flex items-center justify-center gap-2"
                            >
                              <ShoppingBag className="w-5 h-5" />
                              Add to Cart
                            </button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <button
                      onClick={() => handleAddToCart(product)}
                      className="p-3 bg-lumiere-yellow text-black rounded-lg hover:bg-white transition-colors duration-200"
                      aria-label="Add to cart"
                    >
                      <ShoppingBag className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                
                {/* Category tag */}
                <span className="absolute top-3 left-3 px-2 py-1 bg-black/70 text-white text-xs font-medium rounded-full">
                  {product.category}
                </span>
              </div>
              
              {/* Product Info */}
              <div className="mt-3 space-y-1">
                <h3 className="font-display text-sm lg:text-base font-medium text-white group-hover:text-lumiere-yellow transition-colors duration-300 truncate">
                  {product.name}
                </h3>
                <p className="text-lumiere-yellow font-semibold text-sm">
                  ${product.price.toFixed(2)}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <button className="inline-flex items-center gap-2 px-8 py-4 border-2 border-white/20 text-white font-semibold rounded-full hover:bg-lumiere-yellow hover:text-black hover:border-lumiere-yellow transition-all duration-300">
            View All Products
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
}
